package com.capgemini.springboot.controller;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.hateoas.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import com.capgemini.springboot.service.MessageService;
import com.capgemini.springboot.controller.bean.MessageFilterBean;
import com.capgemini.springboot.model.Message;

@RestController
@RequestMapping("/messages")

public class MessageController {
	
	private MessageService messageService = new MessageService();
	
	// Returning Simple Text
		//@GET
	//@RequestMapping(produces = "text/plain")
	public String getMessages(){
		return "Hello World!";
	}
	
	
	@RequestMapping(produces = {"application/xml"})
	public List<Message> getXmlMessages(MessageFilterBean filterBean){
		System.out.println("XML getMessage Called");
		System.out.println(filterBean.getYear());
		if(filterBean.getYear() > 0){
			return messageService.getAllMessagesForYear(filterBean.getYear());
		}
		if(filterBean.getStart() >0 && filterBean.getSize() >=0){
			return messageService.getAllMessagesPaginated(filterBean.getStart(), filterBean.getSize());
		}
		return messageService.getAllMessages();
	}
	
	
	@RequestMapping(produces = {"application/json"})
	public List<Message> getJsonMessages(MessageFilterBean filterBean){
		System.out.println("JSON getMessage Called");
		if(filterBean.getYear() > 0){
			return messageService.getAllMessagesForYear(filterBean.getYear());
		}
		if(filterBean.getStart() >0 && filterBean.getSize() >=0){
			return messageService.getAllMessagesPaginated(filterBean.getStart(), filterBean.getSize());
		}
		return messageService.getAllMessages();
	}
	
	@RequestMapping(value = "/{messageId}")
	public Resource<Message> getMessage(@PathVariable long messageId){
		Message message = messageService.getMessage(messageId);
		Resource<Message> resource = new Resource<Message>(message);
		resource.add(linkTo(methodOn(MessageController.class).getMessage(messageId)).withSelfRel());
		resource.add(linkTo(methodOn(CommentController.class).getAllComments(messageId)).withRel("comments"));
		resource.add(linkTo(methodOn(ProfileController.class).getProfile(message.getAuthor())).withRel("profile"));
		return resource;
	}
	

	//@POST
	/*public Message addMessage(Message message){
		return messageService.addMessage(message);
	}*/ // Below method use to send satus code and link for create record
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<String> addMessage(Message message) throws URISyntaxException{
		Message newMessage = messageService.addMessage(message);	
		HttpHeaders httpHeaders = new HttpHeaders() ;
		URI uriOfMessage = ServletUriComponentsBuilder.fromCurrentContextPath()
			.pathSegment( "messages/{messageId}" )
			.buildAndExpand(newMessage.getMessageId())
			.toUri();
		httpHeaders.setLocation(uriOfMessage);
		
		 return new ResponseEntity<String>(httpHeaders, HttpStatus.CREATED);
	}
	
	
	
	@RequestMapping(method = RequestMethod.PUT, value ="/{messageId}")
	public Message updateMessage(@PathVariable("messageId") long messageId,Message message){
		message.setMessageId(messageId);
		return messageService.updateMessage(message);
	}
	

	@RequestMapping(method = RequestMethod.DELETE, value ="/{messageId}")
	public void deleteMessage(@PathVariable long messageId){
		messageService.deleteMessage(messageId);
	}
	
//	@RequestMapping("/{messageId}/comments")
//	public CommentController getCommentController(){
//		return new CommentController();
//	}

}
