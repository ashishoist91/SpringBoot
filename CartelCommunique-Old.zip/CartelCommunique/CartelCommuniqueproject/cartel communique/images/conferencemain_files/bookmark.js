<!-- Begin
if ((navigator.appName == "Microsoft Internet Explorer") && (parseInt(navigator.appVersion) >= 4)) {
var url="http://www.steves-templates.com";
var title="Steves free web page templates";
document.write('<A class="menu" HREF="javascript:window.ext');
document.write('ernal.AddFavorite(url,title);" ');
document.write('onMouseOver=" window.status=');
document.write("'Add this site to your favorites.'; return true ");
document.write('"onMouseOut=" window.status=');
document.write("' '; return true ");
document.write('">Bookmark</a>');
}
else {
var msg = "";
if(navigator.appName == "Netscape") msg += "  (CTRL-D)";
document.write(msg);
}
// End -->