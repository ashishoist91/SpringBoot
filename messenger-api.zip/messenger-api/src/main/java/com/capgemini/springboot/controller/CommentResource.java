package com.capgemini.springboot.controller;

public class CommentResource {

}
