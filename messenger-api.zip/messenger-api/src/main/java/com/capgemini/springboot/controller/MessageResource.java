package com.capgemini.springboot.controller;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.capgemini.springboot.service.MessageService;
import com.capgemini.springboot.controller.bean.MessageFilterBean;
import com.capgemini.springboot.model.Message;

@RestController
@RequestMapping(value = "/messages")

public class MessageResource {
	
	private MessageService messageService = new MessageService();
	
	// Returning Simple Text
		//@GET
	//@RequestMapping(produces = "text/plain")
	public String getMessages(){
		return "Hello World!";
	}
	
	
	@RequestMapping(produces = {"application/xml"})
	public List<Message> getXmlMessages(MessageFilterBean filterBean){
		System.out.println("XML getMessage Called");
		System.out.println(filterBean.getYear());
		if(filterBean.getYear() > 0){
			return messageService.getAllMessagesForYear(filterBean.getYear());
		}
		if(filterBean.getStart() >0 && filterBean.getSize() >=0){
			return messageService.getAllMessagesPaginated(filterBean.getStart(), filterBean.getSize());
		}
		return messageService.getAllMessages();
	}
	
	
	@RequestMapping(produces = {"application/json"})
	public List<Message> getJsonMessages(MessageFilterBean filterBean){
		System.out.println("JSON getMessage Called");
		if(filterBean.getYear() > 0){
			return messageService.getAllMessagesForYear(filterBean.getYear());
		}
		if(filterBean.getStart() >0 && filterBean.getSize() >=0){
			return messageService.getAllMessagesPaginated(filterBean.getStart(), filterBean.getSize());
		}
		return messageService.getAllMessages();
	}
	
	
	@RequestMapping(value = "/{messageId}")
	public Message getMessage(@PathVariable long messageId){ //@Context UriInfo uriInfo){
		Message message = messageService.getMessage(messageId);
		String uri = uriInfo.getBaseUriBuilder()
				   .path(MessageResource.class)
				   .path(Long.toString(message.getId()))
				   .build()
				   .toString();*/
		//message.addLink(uri, "self");
		
		//String uri = getUriForSelf(uriInfo, message);
		//message.addLink(getUriForSelf(uriInfo, message), "self");
	//	message.addLink(getUriForProfile(uriInfo,message), "profile");
	//	message.addLink(getUriForComments(uriInfo,message), "comments");
		return message;
	}
	
//	private String getUriForComments(UriInfo uriInfo, Message message) {
//		String uri = uriInfo.getBaseUriBuilder()
//				   .path(MessageResource.class)
//				   .path(MessageResource.class,"getCommentResource")
//				   .path(CommentResource.class)
//				   .resolveTemplate("messageId", message.getId())
//				   .build()
//				   .toString();
//		return uri;
//	}
//
//
	private String getUriForProfile(UriInfo uriInfo, Message message) {
		String uri = uriInfo.getBaseUriBuilder()
				   .path(ProfileResource.class)
				   .path(message.getAuthor())
				   .build()
				   .toString();
		return uri;
	}
//
//
//	private String getUriForSelf(UriInfo uriInfo, Message message) {
//		String uri = uriInfo.getBaseUriBuilder()
//			   .path(MessageResource.class)
//			   .path(Long.toString(message.getId()))
//			   .build()
//			   .toString();
//		return uri;
//	}
	
	//@POST
	/*public Message addMessage(Message message){
		return messageService.addMessage(message);
	}*/ // Below method use to send satus code and link for create record
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<String> addMessage(Message message) throws URISyntaxException{
		Message newMessage = messageService.addMessage(message);	
		HttpHeaders httpHeaders = new HttpHeaders() ;
		URI uriOfMessage = ServletUriComponentsBuilder.fromCurrentContextPath()
			.pathSegment( "messages/{messageId}" )
			.buildAndExpand(newMessage.getId())
			.toUri();
		httpHeaders.setLocation(uriOfMessage);
		
		 return new ResponseEntity<String>(httpHeaders, HttpStatus.CREATED);
	}
	
	
	
	@RequestMapping(method = RequestMethod.PUT, value ="/{messageId}")
	public Message updateMessage(@PathVariable("messageId") long messageId,Message message){
		message.setId(messageId);
		return messageService.updateMessage(message);
	}
	

	@RequestMapping(method = RequestMethod.DELETE, value ="/{messageId}")
	public void deleteMessage(@PathVariable long messageId){
		messageService.deleteMessage(messageId);
	}
	
	@RequestMapping("/{messageId}/comments")
	public CommentResource getCommentResource(){
		return new CommentResource();
	}

}
