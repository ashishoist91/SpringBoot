package com.amdocs.jaxrs.messenger.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.amdocs.jaxrs.messenger.database.DatabaseClass;
import com.amdocs.jaxrs.messenger.model.Profile;

public class ProfileService {

private static Map<String, Profile> profiles = DatabaseClass.getProfiles();
	
	public ProfileService() {
		 profiles.put("ashish", new Profile(1L, "ashish", "Ashish", "Singh"));
		 profiles.put("vipin", new Profile(2L, "vipin", "Vipin", "Singh"));
	}
	
	public List<Profile> getAllProfiles(){  
		return new ArrayList<Profile>(profiles.values());
	}
	
	public Profile addProfile(Profile profile){
		profile.setId(profiles.size() + 1);
		profile.setCreated(new Date());
		profiles.put(profile.getProfileName(), profile);
		return profile;
	}
	
	public Profile updateProfile(Profile profile){
		if(profile.getProfileName().isEmpty()){
			return null;
		}
		profiles.put(profile.getProfileName(), profile);
		return profile;
	}
	
	public Profile removeProfile(String profileName){
		return profiles.remove(profileName);
	}
	
	public Profile getProfile(String profileName){
		return profiles.get(profileName);
	}
	
}
