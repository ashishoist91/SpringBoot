
CREATE TABLE ADDRESSBOOK
(
  NAME     VARCHAR2(40 BYTE),
  USERID   VARCHAR2(20 BYTE),
  DOB      VARCHAR2(14 BYTE),
  EMAIL    VARCHAR2(40 BYTE),
  PHONE    VARCHAR2(16 BYTE),
  CITY     VARCHAR2(30 BYTE),
  OUSERID  VARCHAR2(25 BYTE)
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE ADVICES
(
  NAME     VARCHAR2(50 BYTE),
  PHONE    VARCHAR2(14 BYTE),
  EMPID    VARCHAR2(6 BYTE),
  ADDRESS  VARCHAR2(40 BYTE),
  MESSAGE  VARCHAR2(500 BYTE)
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE CLIENTONLINE
(
  USERID     VARCHAR2(25 BYTE),
  ROOMNAME   VARCHAR2(20 BYTE),
  DATEOFLOG  VARCHAR2(25 BYTE),
  TIMEOFLOG  VARCHAR2(25 BYTE)
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE EMPDETAILS
(
  EMPID      NUMBER,
  KEY        VARCHAR2(10 BYTE),
  AC_STATUS  VARCHAR2(1 BYTE),
  DOJ        VARCHAR2(10 BYTE),
  USERID     VARCHAR2(25 BYTE)
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE HELLO
(
  USERID  VARCHAR2(25 BYTE),
  TEXT    LONG
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE JAVA
(
  USERID  VARCHAR2(25 BYTE),
  TEXT    LONG
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE MAIL
(
  USERID   VARCHAR2(25 BYTE),
  WHOSEND  VARCHAR2(25 BYTE),
  MESSAGE  LONG,
  TIMING   VARCHAR2(50 BYTE),
  READ     CHAR(1 BYTE),
  SUBJECT  VARCHAR2(25 BYTE)
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE PASSWORD
(
  USERID  VARCHAR2(25 BYTE),
  PWD     VARCHAR2(20 BYTE),
  BAN     VARCHAR2(1 BYTE)
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE ROOMDETAILS
(
  ROOMNAME   VARCHAR2(25 BYTE),
  RIN        VARCHAR2(20 BYTE),
  MODERATOR  VARCHAR2(25 BYTE)
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE SECURITY
(
  USERID  VARCHAR2(25 BYTE),
  QUES    VARCHAR2(100 BYTE),
  ANS     VARCHAR2(50 BYTE)
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE STRUTS
(
  USERID  VARCHAR2(25 BYTE),
  TEXT    LONG
)
TABLESPACE USERS
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE USERDETAILS
(
  USERID     VARCHAR2(25 BYTE),
  NAME       VARCHAR2(25 BYTE),
  ADDRESS    VARCHAR2(50 BYTE),
  ZIP        VARCHAR2(6 BYTE),
  PHONE      VARCHAR2(12 BYTE),
  EMAIL      VARCHAR2(50 BYTE),
  SEX        VARCHAR2(1 BYTE),
  EDUCATION  VARCHAR2(30 BYTE),
  COUNTRY    VARCHAR2(25 BYTE),
  CITY       VARCHAR2(20 BYTE),
  STATE      VARCHAR2(25 BYTE),
  DOB        VARCHAR2(12 BYTE)
)
TABLESPACE SYSTEM
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;



Insert into ADDRESSBOOK
   (NAME, USERID, DOB, EMAIL, PHONE, 
    CITY, OUSERID)
 Values
   ('admin', 'admin', '01/jan/1980', 'admin@yahoo.com', '123456', 
    'hyderabad', 'sunil');
Insert into ADDRESSBOOK
   (NAME, USERID, DOB, EMAIL, PHONE, 
    CITY, OUSERID)
 Values
   ('karthik', 'karthik', '20/mar/1992', 'karthik@gmail.com', '234567', 
    'hyd', 'admin');
COMMIT;

Insert into ADVICES
   (NAME, PHONE, EMPID, ADDRESS, MESSAGE)
 Values
   ('sunil', '12345567', '1', 'hyd', 'abcdefghi');
Insert into ADVICES
   (NAME, PHONE, EMPID, ADDRESS, MESSAGE)
 Values
   ('sunil', '12345567', '1', 'hyd', 'abcdefghi');
COMMIT;

Insert into CLIENTONLINE
   (USERID, ROOMNAME, DATEOFLOG, TIMEOFLOG)
 Values
   ('vara', NULL, '02-Feb-2009 ', '22:35:13');
COMMIT;

Insert into EMPDETAILS
   (EMPID, KEY, AC_STATUS, DOJ, USERID)
 Values
   (1, '100', 'y', '12/12/2007', 'sunil');
Insert into EMPDETAILS
   (EMPID, KEY, AC_STATUS, DOJ, USERID)
 Values
   (2, '456', 'y', '01/01/2009', 'hello');
Insert into EMPDETAILS
   (EMPID, KEY, AC_STATUS, DOJ, USERID)
 Values
   (3, '789', 'n', '10/01/2009', 'sunilm');
Insert into EMPDETAILS
   (EMPID, KEY, AC_STATUS, DOJ, USERID)
 Values
   (4, '700', 'y', '05/02/209', 'vara');
Insert into EMPDETAILS
   (EMPID, KEY, AC_STATUS, DOJ, USERID)
 Values
   (5, '200', 'n', '01/01/2009', NULL);
Insert into EMPDETAILS
   (EMPID, KEY, AC_STATUS, DOJ, USERID)
 Values
   (6, '300', 'y', '01/01/2009', 'sunil');
Insert into EMPDETAILS
   (EMPID, KEY, AC_STATUS, DOJ, USERID)
 Values
   (7, '800', 'y', '01/01/2009', 'suni');
Insert into EMPDETAILS
   (EMPID, KEY, AC_STATUS, DOJ, USERID)
 Values
   (8, '999', 'n', '01/01/2010', NULL);
COMMIT;

Insert into HELLO
   (USERID, TEXT)
 Values
   ('sunil', 'hello admin');
COMMIT;

Insert into JAVA
   (USERID, TEXT)
 Values
   ('admin', 'hello');
Insert into JAVA
   (USERID, TEXT)
 Values
   ('admin', 'hi');
COMMIT;

Insert into MAIL
   (USERID, WHOSEND, MESSAGE, TIMING, READ, 
    SUBJECT)
 Values
   ('sunil', 'admin', 'jfhdk', 'Tue Feb 10 13:56:06 IST 2009', 'y', 
    'hello');
Insert into MAIL
   (USERID, WHOSEND, MESSAGE, TIMING, READ, 
    SUBJECT)
 Values
   ('admin', 'sunil', 'hhh', 'Tue Feb 10 14:02:03 IST 2009', 'y', 
    'hjfd');
Insert into MAIL
   (USERID, WHOSEND, MESSAGE, TIMING, READ, 
    SUBJECT)
 Values
   ('sunil', 'admin', 'Hi Guys,
   there is demo for the traing of struts Frame work.', 'Fri Jan 22 16:48:34 IST 2010', 'n', 
    'training about  struts');
Insert into MAIL
   (USERID, WHOSEND, MESSAGE, TIMING, READ, 
    SUBJECT)
 Values
   ('vara', 'admin', 'Hi Guys,
   there is demo for the traing of struts Frame work.', 'Fri Jan 22 16:48:34 IST 2010', 'n', 
    'training about  struts');
Insert into MAIL
   (USERID, WHOSEND, MESSAGE, TIMING, READ, 
    SUBJECT)
 Values
   ('sunil', 'admin', 'Hi Guys,
   there is demo for the traing of struts Frame work.', 'Fri Jan 22 16:49:18 IST 2010', 'n', 
    'training about  struts');
Insert into MAIL
   (USERID, WHOSEND, MESSAGE, TIMING, READ, 
    SUBJECT)
 Values
   ('vara', 'admin', 'Hi Guys,
   there is demo for the traing of struts Frame work.', 'Fri Jan 22 16:49:18 IST 2010', 'n', 
    'training about  struts');
Insert into MAIL
   (USERID, WHOSEND, MESSAGE, TIMING, READ, 
    SUBJECT)
 Values
   ('sunil', 'admin', 'Hi Guys,
   there is demo for the traing of struts Frame work.', 'Fri Jan 22 16:49:32 IST 2010', 'n', 
    'training about  struts');
Insert into MAIL
   (USERID, WHOSEND, MESSAGE, TIMING, READ, 
    SUBJECT)
 Values
   ('vara', 'admin', 'Hi Guys,
   there is demo for the traing of struts Frame work.', 'Fri Jan 22 16:49:32 IST 2010', 'n', 
    'training about  struts');
COMMIT;

Insert into PASSWORD
   (USERID, PWD, BAN)
 Values
   ('admin', 'admin', 'n');
Insert into PASSWORD
   (USERID, PWD, BAN)
 Values
   ('sunil', '123456', 'n');
Insert into PASSWORD
   (USERID, PWD, BAN)
 Values
   ('hello', 'hello', 'n');
Insert into PASSWORD
   (USERID, PWD, BAN)
 Values
   ('vara', 'vara', 'n');
Insert into PASSWORD
   (USERID, PWD, BAN)
 Values
   ('suni', 'suni', 'n');
COMMIT;

Insert into ROOMDETAILS
   (ROOMNAME, RIN, MODERATOR)
 Values
   ('java', '100', 'admin');
Insert into ROOMDETAILS
   (ROOMNAME, RIN, MODERATOR)
 Values
   ('hello', '400', 'sunil');
Insert into ROOMDETAILS
   (ROOMNAME, RIN, MODERATOR)
 Values
   ('struts', '500', 'admin');
COMMIT;

Insert into SECURITY
   (USERID, QUES, ANS)
 Values
   ('sunil', 'about us', 'abcd');
Insert into SECURITY
   (USERID, QUES, ANS)
 Values
   ('hello', 'hjhh', 'jhkhk');
Insert into SECURITY
   (USERID, QUES, ANS)
 Values
   ('vara', 's', 's');
Insert into SECURITY
   (USERID, QUES, ANS)
 Values
   ('sunil', 'what is java', 'i dont know');
Insert into SECURITY
   (USERID, QUES, ANS)
 Values
   ('suni', 'aaaa', 'i dont know');
COMMIT;

Insert into STRUTS
   (USERID, TEXT)
 Values
   ('admin', 'hi');
Insert into STRUTS
   (USERID, TEXT)
 Values
   ('admin', 'hello');
Insert into STRUTS
   (USERID, TEXT)
 Values
   ('admin', 'learn struts');
Insert into STRUTS
   (USERID, TEXT)
 Values
   ('sunil', 'hi admin');
Insert into STRUTS
   (USERID, TEXT)
 Values
   ('sunil', 'truts ');
COMMIT;

Insert into USERDETAILS
   (USERID, NAME, ADDRESS, ZIP, PHONE, 
    EMAIL, SEX, EDUCATION, COUNTRY, CITY, 
    STATE, DOB)
 Values
   ('sunil', 'sunil', 'ameerpet', '530221', '0404123456', 
    'sunil@yahoo.com', 'm', 'btech', 'India', 'Hyderabad', 
    'Andhra Pradesh', '01-jan-1980');
Insert into USERDETAILS
   (USERID, NAME, ADDRESS, ZIP, PHONE, 
    EMAIL, SEX, EDUCATION, COUNTRY, CITY, 
    STATE, DOB)
 Values
   ('suni', 'kumar s sunil', 'ameerpet', '123456', '0404123456', 
    'kumar@yahoo.com', 'm', 'btech', 'India', 'Hyderabad', 
    'Andhra Pradesh', '01-jul-1983');
Insert into USERDETAILS
   (USERID, NAME, ADDRESS, ZIP, PHONE, 
    EMAIL, SEX, EDUCATION, COUNTRY, CITY, 
    STATE, DOB)
 Values
   ('vara', 's s s', 's', '1', '221221', 
    'suri0542@yahoo.com', 'm', 'MCA', 'India', 'Hyderabad', 
    'Andhra Pradesh', '19-nov-1985');
COMMIT;

