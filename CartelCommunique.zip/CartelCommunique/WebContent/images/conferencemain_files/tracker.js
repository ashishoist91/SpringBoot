<!--
document.write("<a href=\"http://top.addfreestats.com/cgi-bin/main.cgi?usr=00108809P000\" target=\"_blank\">");
document.write("<img src=\"http://www1.addfreestats.com");
document.write("/cgi-bin/connect.cgi?");
document.write("usr=00108809P000");
document.write("&refer="+escape(document.referrer)+"");
document.write("&tips="+Math.random()+"");
document.write("\" alt=\"AddFreeStats\" border=0></A>");
//-->