package com.dbs.spring;

import com.dbs.spring.domain.Encryption;
import com.dbs.spring.domain.Messaging;

public class Communication {
	
	
	private Messaging  messaging;
	
	private Encryption encryption;

	
	
	public Communication(Encryption encryption) {
		super();
		this.encryption = encryption;
	}

	public void setMessaging(Messaging messaging) {
		this.messaging = messaging;
	}


	public void communicate() {
		encryption.encryptData();
		messaging.sendmessage();
	}
	
	

}
