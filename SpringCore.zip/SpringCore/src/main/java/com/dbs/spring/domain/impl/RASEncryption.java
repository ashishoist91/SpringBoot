package com.dbs.spring.domain.impl;

import com.dbs.spring.domain.Encryption;

public class RASEncryption implements Encryption {

	public void encryptData() {
		System.out.println("Encrypting Data Using RSA Encryption");

	}

}
