package com.dbs.spring.domain;

public interface Messaging {

	public void sendmessage();
}
