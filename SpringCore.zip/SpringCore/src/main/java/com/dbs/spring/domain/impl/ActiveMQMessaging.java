package com.dbs.spring.domain.impl;

import com.dbs.spring.domain.Messaging;

public class ActiveMQMessaging implements Messaging {

	public void sendmessage() {
		System.out.println("Messaging Data Using ActiveMQMessaging");


	}

}
