package com.dbs.spring.domain;

public interface Encryption {
	
	public void encryptData();

}
