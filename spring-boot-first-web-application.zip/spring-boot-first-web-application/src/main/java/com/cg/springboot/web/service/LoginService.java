package com.cg.springboot.web.service;

import org.springframework.stereotype.Component;

@Component
public class LoginService {

	public boolean validateUser(String userid, String password) {
		//ashish ashish
		return userid.equalsIgnoreCase("ashish")
				&& password.equalsIgnoreCase("ashish");
	}

}