package com.ashish.springboot.domain;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Topics")
public class TopicList {
	
	List<Topic> listOfTopics;

	public TopicList() {
		super();
		
	}

	public TopicList(List<Topic> listOfTopics) {
		super();
		this.listOfTopics = listOfTopics;
	}

	public List<Topic> getListOfTopics() {
		return listOfTopics;
	}
	
	@XmlElement(name = "Topic")
	public void setListOfTopics(List<Topic> listOfTopics) {
		this.listOfTopics = listOfTopics;
	}

}
