package com.ashish.springboot.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.ashish.springboot.service.TopicService;
import com.ashish.springboot.domain.Topic;
import com.ashish.springboot.domain.TopicList;

@RestController
@RequestMapping("/course-api")
public class TopicController {
	
	@Autowired
	private TopicService topicService;
	

	
	@RequestMapping(value = "/topics", method = RequestMethod.GET,headers="Accept=application/xml")
	public TopicList getCountries()
	{
		TopicList topicList=new TopicList(topicService.getAllTopics());
		return topicList;
	}
	

	
	@RequestMapping(value = "/topics/{id}", method = RequestMethod.GET, produces="application/xml")
	public Topic getTopic(@PathVariable String id){
		return topicService.getTopic(id);
	}
	
//	@RequestMapping(value = "/topics", method = RequestMethod.POST)
//	public Topic addTopic(@RequestBody Topic topic) {
//		return topicService.addTopic(topic);
//	}
	
	@RequestMapping(value = "/topics", method = RequestMethod.POST)
	public ResponseEntity<?> addTopic(@RequestBody Topic topic, UriComponentsBuilder ucBuilder) {
		topicService.addTopic(topic);
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/course-api/topics/{id}").buildAndExpand(topic.getId()).toUri());
		return new ResponseEntity<String>(headers, HttpStatus.CREATED);
		//return ;
	}
	
	@RequestMapping(value = "/topics/{id}", method = RequestMethod.PUT)
	public void updateTopic(@RequestBody Topic topic, @PathVariable String id) {
		topicService.updateTopic(topic, id);
	}
	
	@RequestMapping(value = "/topics/{id}", method = RequestMethod.DELETE)
	public void deleteTopic(@PathVariable String id) {
		topicService.deleteTopic(id);
	}


}
