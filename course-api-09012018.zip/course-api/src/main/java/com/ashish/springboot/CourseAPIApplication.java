package com.ashish.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseAPIApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseAPIApplication.class, args);
		

	}

}
