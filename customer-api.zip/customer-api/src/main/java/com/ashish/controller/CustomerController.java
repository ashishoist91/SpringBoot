package com.ashish.controller;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import javax.xml.ws.Response;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

import com.ashish.domain.Customer;

//import scala.sys.process.processInternal;



@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	private Map<Integer, Customer> customerDB =
            new ConcurrentHashMap<Integer, Customer>();
	
	private AtomicInteger idCounter = new AtomicInteger();
	
	
	
	@RequestMapping(value = "{id}", produces = "application/xml")
	public Customer getCustomerByid(@PathVariable int id){
		customerDB.put(1, new Customer(1,"Ashish",50.4));
		customerDB.put(2, new Customer(2,"Vipin",50.4));
		
		//System.out.println(identifier);
		return customerDB.get(1);

	}

	
	public Response createCustomer(Customer customer) {
		return null;
	}
	

}
