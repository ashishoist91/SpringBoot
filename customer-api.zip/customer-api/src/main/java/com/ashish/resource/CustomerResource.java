package com.ashish.resource;

public class CustomerResource {

}
