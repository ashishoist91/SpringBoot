package com.capgemini.springboot.exception;


public class ErrorResponse {
	private int errorCode;
	private String message;
	private String url;

	
	public ErrorResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ErrorResponse(int errorCode, String message, String url) {
		super();
		this.errorCode = errorCode;
		this.message = message;
		this.url = url;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	
}