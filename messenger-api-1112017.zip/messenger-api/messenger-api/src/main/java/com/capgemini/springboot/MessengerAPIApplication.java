package com.capgemini.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessengerAPIApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessengerAPIApplication.class, args);
	}

}
