package com.capgemini.springboot.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.hateoas.ResourceSupport;

@XmlRootElement
public class Comment extends ResourceSupport {
	
	private long commentId;
	private String message;
	private String author;
	private Date created;
	
	
	
	public Comment() {
		super();
	}
	public Comment(long commentId, String message, String author) {
		super();
		System.out.println("Calling Comment Constructor");
		this.commentId = commentId;
		this.message = message;
		this.author = author;
		this.created = new Date();
	}
	public long getCommentId() {
		return commentId;
	}
	public void setCommentId(long commentId) {
		this.commentId = commentId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	@Override
	public String toString() {
		return "Comment [commentId=" + commentId + ", message=" + message + ", author=" + author + ", created="
				+ created + "]";
	}
	
	
	
	
}