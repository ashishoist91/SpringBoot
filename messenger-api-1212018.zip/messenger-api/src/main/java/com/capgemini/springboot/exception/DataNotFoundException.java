package com.capgemini.springboot.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;


@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="No such Order")

public class DataNotFoundException extends RuntimeException{

	private static final long serialVersionUID = -6328286661536343936L;
	
	public DataNotFoundException(String message) {
		super(message);
	}
	
	
}
