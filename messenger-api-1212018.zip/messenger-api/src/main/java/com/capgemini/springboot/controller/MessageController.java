package com.capgemini.springboot.controller;

import java.util.List;

import javax.validation.Valid;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.hateoas.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import com.capgemini.springboot.service.MessageService;
import com.capgemini.springboot.controller.bean.MessageFilterBean;
import com.capgemini.springboot.exception.DataNotFoundException;
import com.capgemini.springboot.model.Message;

@RestController
@RequestMapping("/messages")

public class MessageController {
	
	private MessageService messageService = new MessageService();
	
	
	@RequestMapping(produces = {"application/xml"})
	public List<Message> getXmlMessages(MessageFilterBean filterBean){
		System.out.println("XML getMessage Called");
		System.out.println(filterBean.getYear());
		if(filterBean.getYear() > 0){
			return messageService.getAllMessagesForYear(filterBean.getYear());
		}else {
			
		}
		if(filterBean.getStart() >0 && filterBean.getSize() >=0){
			return messageService.getAllMessagesPaginated(filterBean.getStart(), filterBean.getSize());
		}else {
			
		}
		return messageService.getAllMessages();
	}
	
	
	@RequestMapping(produces = {"application/json"})
	public List<Message> getJsonMessages(MessageFilterBean filterBean){
		System.out.println("JSON getMessage Called");
		if(filterBean.getYear() > 0){
			return messageService.getAllMessagesForYear(filterBean.getYear());
		}
		if(filterBean.getStart() >0 && filterBean.getSize() >=0){
			return messageService.getAllMessagesPaginated(filterBean.getStart(), filterBean.getSize());
		}
		return messageService.getAllMessages();
	}
	
	@RequestMapping(value = "/{messageId}")
	public Resource<Message> getMessage(@PathVariable long messageId) throws DataNotFoundException {
		if(messageId < 0) {
			throw new DataNotFoundException("Invalid Message id requested");
		}
		Message message = messageService.getMessage(messageId);
		Resource<Message> resource = new Resource<Message>(message);
		resource.add(linkTo(methodOn(MessageController.class).getMessage(messageId)).withSelfRel());
		resource.add(linkTo(methodOn(CommentController.class).getAllComments(messageId)).withRel("comments"));
		resource.add(linkTo(methodOn(ProfileController.class).getProfile(message.getAuthor())).withRel("profile"));
		return resource;
	}
	

	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<String> addMessage(@RequestBody Message message) {
		if(message == null || message.getMessage() == null || message.getMessage().length() < 1 || 
				message.getAuthor() == null || message.getAuthor().length() < 1) {
			throw new IllegalArgumentException("Input Data is not correct");
		}
		Message newMessage = messageService.addMessage(message);	
		HttpHeaders httpHeaders = new HttpHeaders() ;
		URI uriOfMessage = ServletUriComponentsBuilder.fromCurrentContextPath()
			.pathSegment( "messages/{messageId}" )
			.buildAndExpand(newMessage.getMessageId())
			.toUri();
		httpHeaders.setLocation(uriOfMessage);
		
		 return new ResponseEntity<String>(httpHeaders, HttpStatus.CREATED);
	}
	
	
	
	@RequestMapping(method = RequestMethod.PUT, value ="/{messageId}")
	public Message updateMessage(@PathVariable("messageId") long messageId,Message message){
		message.setMessageId(messageId);
		return messageService.updateMessage(message);
	}
	

	@RequestMapping(method = RequestMethod.DELETE, value ="/{messageId}")
	public void deleteMessage(@PathVariable long messageId){
		messageService.deleteMessage(messageId);
	}
	
// Example related to 	
//	@ExceptionHandler(MessageException.class)
//	public ResponseEntity<ErrorResponse> exceptionHandler(Exception ex) {
//		ErrorResponse error = new ErrorResponse();
//		error.setErrorCode(HttpStatus.PRECONDITION_FAILED.value());
//		error.setMessage(ex.getMessage());
//		return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
//	}

}
