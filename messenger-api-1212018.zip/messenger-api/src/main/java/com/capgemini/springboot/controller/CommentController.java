package com.capgemini.springboot.controller;

import java.net.URI;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriTemplate;

import com.capgemini.springboot.exception.DataNotFoundException;
import com.capgemini.springboot.model.Comment;
import com.capgemini.springboot.service.CommentService;


@RestController
@RequestMapping("/messages/{messageId}/comments")
public class CommentController {
	private CommentService commentService = new CommentService();
	
	@RequestMapping
	public List<Comment> getAllComments(@PathVariable long messageId) throws DataNotFoundException{
		return commentService.getAllComments(messageId);
	}
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/{commentId}")
	public Comment getComment(@PathVariable long messageId, @PathVariable long commentId) throws DataNotFoundException{
		return commentService.getComment(messageId, commentId);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/{commentId}")
	public Comment updateComment(@PathVariable long messageId, @PathVariable long commentId, Comment comment){
		comment.setCommentId(commentId);
		commentService.updateComment(messageId, comment);
		return comment;
	}
	@RequestMapping(method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public void addComment(@PathVariable("messageId") long messageId, @RequestBody Comment comment, HttpServletRequest request,
			HttpServletResponse response){		
		Comment newComment = commentService.addComment(messageId, comment);
		String requestUrl = request.getRequestURL().toString();
		URI uri = new UriTemplate("{requestUrl}/{commentId}").expand(requestUrl, newComment.getCommentId());
		response.setHeader("Location", uri.toASCIIString());
	}
	
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/{commentId}")
	public void removeComment(@PathVariable long messageId, @PathVariable long commentId){
		commentService.removeComment(messageId, commentId);
	}
}
