package com.capgemini.springboot.exception;

import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.capgemini.springboot.model.ErrorMessage;

@ControllerAdvice
public class MessengerExceptionProcessor {

	
	
	@ExceptionHandler(DataNotFoundException.class)
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	@ResponseBody
	public ErrorMessage dataNotFound(HttpServletRequest  req, DataNotFoundException exception) {
		
		ErrorMessage errorMessage = new ErrorMessage();
		errorMessage.setErrorCode(HttpStatus.NOT_FOUND.value());
		errorMessage.setErrorMessage(exception.getMessage());
		errorMessage.setPath(req.getRequestURI());
		errorMessage.setDocumentation("Visit : https://www.google.com for more help");
		return errorMessage;
	}
	
	
	@ExceptionHandler(IllegalArgumentException.class)
	@ResponseBody
	public ErrorMessage illegalArgumentException(HttpServletRequest  req, IllegalArgumentException exception) {
		
		ErrorMessage errorMessage = new ErrorMessage();
		errorMessage.setErrorCode(HttpStatus.BAD_REQUEST.value());
		errorMessage.setErrorMessage(exception.getMessage());
		errorMessage.setPath(req.getRequestURI());
		errorMessage.setDocumentation("Visit : https://www.google.com for more help");
		return errorMessage;
	}
	
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseBody
	public ErrorMessage illegalArgumentException(HttpServletRequest  req, MethodArgumentNotValidException exception) {
		
		StringBuilder message = new StringBuilder();
		int count = 1;
		for(ObjectError error : exception.getBindingResult().getAllErrors()) {
			message.append(" " + count++ + "." + error.getDefaultMessage());
		}
		ErrorMessage errorMessage = new ErrorMessage();
		errorMessage.setErrorCode(HttpStatus.BAD_REQUEST.value());
		errorMessage.setErrorMessage(message.toString());
		errorMessage.setPath(req.getRequestURI());
		errorMessage.setDocumentation("Visit : https://www.google.com for more help");
		return errorMessage;
	}
	
//	@ExceptionHandler
//    @ResponseBody
//	public Map handle(MethodArgumentNotValidException exception) {
//        return error(exception.getBindingResult().getFieldErrors()
//                .stream()
//                .map(FieldError::getDefaultMessage)
//                .collect(Collectors.toList()));
//    }
//	
//	
//	private Map error(Object message) {
//        return Collections.singletonMap("errorssss", message);
//    }
}
