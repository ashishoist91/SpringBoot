package com.capgemini.springboot.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springboot.model.Profile;
import com.capgemini.springboot.service.ProfileService;

@RestController
@RequestMapping("/profiles")
public class ProfileController {
	
	private ProfileService profileService = new ProfileService();
	
	
	@RequestMapping(method = RequestMethod.GET)
	public List<Profile> getProfiles(){
		return profileService.getAllProfiles();
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/{profileName}")
	public Profile getProfile(@PathVariable String profileName){
		return profileService.getProfile(profileName);
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public Profile addProfile(@Valid @RequestBody Profile profile){
		return profileService.addProfile(profile);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/{profileName}")
	public Profile updateProfile(@PathVariable String profileName,Profile profile){
		profile.setProfileName(profileName);
		return profileService.updateProfile(profile);
	}

	

	@RequestMapping(value = "/{profileName}", method = RequestMethod.DELETE)
	public void deleteProfile(@PathVariable String profileName){
		profileService.removeProfile(profileName);
	}
}
